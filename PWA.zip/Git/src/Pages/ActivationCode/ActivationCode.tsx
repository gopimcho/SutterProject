import React, { useEffect, useState } from "react";
import "./ActivationCode.css"
import { useNavigate } from "react-router-dom";

const ActivationCode: React.FC = () => {

    const [formValue, setFormVales] = useState({activationCode:""});
    const [disabled, setDisabled] = useState('typing');
    
    const handelInupt = (e: any) => {
        console.log(e.target);
       const {name, value} = e.target;
       setFormVales({...formValue, [name]:value}) 
    }
 
    const handleSubmite= (e: any) =>{
           e.preventDefault();
           console.log(formValue);
    }

    return (
        <div className="activation-code-page">
            <p className="headding-text">Enter Activation Code </p>
            <form onSubmit={handleSubmite}>
            <div className="input-group mb-3">
                <input type="text"
                       className="form-control"
                       aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default"
                       placeholder="Type your Activation Code"
                       name="activationCode"
                       value={formValue.activationCode}
                       onChange={handelInupt} />
            </div>
            <div className="button-position">
                <button type="button"
                        className="btn btn-secondary btn-disable" 
                        disabled={formValue.activationCode.length===0}>
                    Enter    
                </button>
            </div>
            </form>
            <div className="content-data">
                <h4 className="question-list">Don't have activation code? </h4>
                <p className="list-data">
                    This is a closed research pilot study.
                    If you care team is participating in the
                    study and feel you would be a good fit,
                    they will provide you with additional
                    information.
                </p>
                <p className="list-content">
                    If your care team has discussed this
                    pilot study with you, and you never
                    received/misplaced the activation
                    code, please contact them.
                </p>
            </div>
        </div>
    )
};

export default ActivationCode;