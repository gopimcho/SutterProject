import React, { useEffect } from "react";
import "./Welcome.css"
import { useNavigate } from "react-router-dom";
// import'./Pages/WelcomePage/Welcome.css';

const Welcome: React.FC = () => {

    const navigate = useNavigate();

    // useEffect(() => {
    //   const hasVisited = localStorage.getItem('hasVisitedWelcome');
    //   if (hasVisited) {
    //     navigate('/terms');
    //   }
    // }, [navigate]);

    const handleGetStartedClick = () => {
        //localStorage.setItem('hasVisitedWelcome', 'true');
        navigate("/ActivationCode");
    };


    return (
        <div className="welcome-page">
            <h1 className="welcome-text">Welcome!</h1>
            <div className="main-div">
                <p className="our-goal">
                    Our goal is the same as yours, to get you through treatment and on
                    with life.
                </p>
                <p className="onc-share">OncSHARE is designed to keep us connected along the way.</p>
                <p>You can:</p>
                <ul>
                    <li>Manage your medicine schedule.</li>
                    <li>Track your treatment cycles.</li>
                    <li>Report issues or symptoms.</li>
                    <li>Find helpful resources.</li>
                </ul>
                <p>With OncSHARE we can follow your progress and offer support when you need it.</p>
                {/* <button className="get-started-button" onClick={handleGetStartedClick}>Get Started</button> */}
                {/* <div className="d-grid gap-2"> */}
                {/* <button
          type="button"
          className="btn btn-primary btn-color"
          onClick={handleGetStartedClick}>
          Get Started
        </button> */}
                {/* <button className="btn btn-primary btn-block mt-4" style={{ backgroundColor: 'teal', color: 'white' }}>Get Started
      </button> */}

                <div className="get-started-container">
                    <button
                        className="btn btn-primary btn-block mt-4"
                        style={{ backgroundColor: "teal", color: "white" }}
                        onClick={handleGetStartedClick} >
                        Get Started
                    </button>
                    {/* </div> */}
                </div>
            </div>
        </div>
    );
};


export default Welcome;