import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Welcome from './Pages/WelcomePage/Welocome';
import ActivationCode from './Pages/ActivationCode/ActivationCode';
import './App.css';
import './Style/global.css';

function App() {
  return (
    <div className="App container-fluid" >
      <Router>
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/ActivationCode" element={<ActivationCode />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;

